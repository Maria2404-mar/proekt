QT += widgets

CONFIG += c++17
CONFIG += warn_off

# Для macOS
macx {
    QMAKE_CXXFLAGS += -Wno-implicit-function-declaration
    QMAKE_CXXFLAGS += -Wno-deprecated-declarations
    QMAKE_CXXFLAGS += -Wno-unused-parameter
}

TARGET = PastelGirl
TEMPLATE = app

DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    tictactoe.cpp

HEADERS += \
    mainwindow.h \
    tictactoe.h

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

# Для macOS
macx {
    ICON = app.icns
    QMAKE_INFO_PLIST = Info.plist
}
