#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMap>
#include <QString>
#include <QList>
#include <QTimer>
#include <QPixmap>
#include <QRandomGenerator>

QT_BEGIN_NAMESPACE
class QLabel;
class QPushButton;
class QScrollArea;
class QVBoxLayout;
class QHBoxLayout;
class QWidget;
class QStackedWidget;
QT_END_NAMESPACE

class TicTacToe;

struct ItemConfig {
    int width;
    int height;
    int offsetX;
    int offsetY;
};

struct CategoryData {
    QString label;
    QStringList items;
};

struct ClothingItem {
    QString name;
    QString category;
    QString file;
    int price;
    bool isUnlocked;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void startGame();
    void showRandomPlace();
    void goToSelectionScreen();
    void goToDollGame();
    void goToTicTacToe();
    void selectCategory(const QString &category);
    void selectItem(const QString &category, const QString &item);
    void removeItem();
    void updateMoneyDisplay();
    void addMoney(int amount);
    void openShop();
    void onTicTacToeWin();

private:
    void setupUI();
    void setupStartScreen();
    void setupRandomScreen();
    void setupSelectionScreen();
    void setupDollGameScreen();
    void setupDoll();
    void updateDoll();
    QString getPath(const QString &category, const QString &item) const;
    ItemConfig getConfig(const QString &category, const QString &item) const;
    void clearLayout(QLayout *layout);
    void debugPaths();
    void setupClothingShop();
    bool canAfford(int price);
    void unlockItem(const QString &category, const QString &item);
    void saveData();
    void loadData();

    // Основные виджеты
    QStackedWidget *stackedWidget;

    // Страница 1: Заставка
    QWidget *startScreen;
    QPushButton *playButton;

    // Страница 2: Рандомайзер
    QWidget *randomScreen;
    QLabel *placeNameLabel;
    QLabel *placeImageLabel;
    QPushButton *randomButton;
    QPushButton *goButton;
    QString currentPlace;
    QTimer *animationTimer;
    int animationStep;
    QStringList animationPlaces;

    // Страница 3: Выбор игры
    QWidget *selectionScreen;
    QPushButton *dollGameButton;
    QPushButton *tictactoeButton;
    QLabel *placeDisplaySelection;
    QLabel *moneyLabelSelection;
    QPushButton *shopButtonSelection;

    // Страница 4: Игра с куклой
    QWidget *dollGameScreen;
    QLabel *moneyLabelDoll;
    QPushButton *shopButtonDoll;

    // Страница 5: Крестики-нолики
    TicTacToe *tictactoeGame;
    QWidget *tictactoeContainer;

    // Данные куклы
    QMap<QString, QString> dollState;
    QString currentCategory;

    // Категории и их элементы
    QMap<QString, CategoryData> categories;
    QMap<QString, QMap<QString, ItemConfig>> itemConfigs;

    // Виджеты куклы
    QLabel *bodyLabel;
    QLabel *hairLabel;
    QLabel *eyesLabel;
    QLabel *browsLabel;
    QLabel *mouthLabel;
    QLabel *topLabel;
    QLabel *jacketLabel;
    QLabel *bottomLabel;
    QLabel *shoesLabel;
    QLabel *bagLabel;
    QLabel *hatLabel;

    // Контейнер для куклы
    QWidget *dollContainer;

    // Кнопки категорий
    QMap<QString, QPushButton*> categoryButtons;
    QVBoxLayout *categoryLayout;

    // Панель предметов
    QScrollArea *itemsScrollArea;
    QWidget *itemsPanel;
    QHBoxLayout *itemsLayout;

    // Список мест
    QStringList places;

    // Валюта и магазин
    int money;
    QMap<QString, QMap<QString, ClothingItem>> shopItems;
    QWidget *shopWindow;
    bool shopOpen;
};

#endif // MAINWINDOW_H
