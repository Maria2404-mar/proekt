#ifndef TICTACTOE_H
#define TICTACTOE_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QGridLayout>
#include <QTimer>

class TicTacToe : public QWidget
{
    Q_OBJECT

public:
    TicTacToe(QWidget *parent = nullptr);

signals:
    void playerWon();  // Сигнал о победе игрока

private slots:
    void handleButtonClick();
    void resetGame();
    void aiMove();

private:
    QPushButton* buttons[3][3];
    QLabel* statusLabel;
    QPushButton* resetButton;
    char currentPlayer;
    bool gameOver;
    bool isAITurn;
    bool isPlayerTurn;
    int moveCount;
    bool robotStarts;

    void checkWinner();
    void setStatus(const QString& text);
    void disableAllButtons();
    void enableAllButtons();
    void clearBoard();
    bool isBoardFull();
    int evaluateBoard();
    int minimax(bool isMaximizing, int depth, int alpha, int beta, int maxDepth);
    QPair<int, int> findBestMove();
    void makeAIMove(int row, int col);
    void startNewGame();
    void showCustomMessage(const QString &title, const QString &text);  // НОВАЯ ФУНКЦИЯ
};

#endif
