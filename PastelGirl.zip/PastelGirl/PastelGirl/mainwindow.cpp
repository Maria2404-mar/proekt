#include "mainwindow.h"
#include "tictactoe.h"
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include <QScrollBar>
#include <QFile>
#include <QApplication>
#include <QPixmap>
#include <QStandardPaths>
#include <QPainter>
#include <QBitmap>
#include <QStackedWidget>
#include <QTimer>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include <QDir>
#include <QSettings>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), money(0), shopOpen(false), shopWindow(nullptr)
{
    // Инициализация мест
    places = {"АЭРОПОРТ ✈️", "КОФЕ ☕", "БИБЛИОТЕКА 📚", "ПЛЯЖ 🏖️"};
    animationStep = 0;
    animationPlaces = places;
    currentPlace = "";

    // Инициализация состояния куклы
    dollState["body"] = "body";
    dollState["hair"] = "hair_1";
    dollState["eyes"] = "eyes_1";
    dollState["brows"] = "brows_1";
    dollState["mouth"] = "mouth_1";
    dollState["jackets"] = "";
    dollState["tops"] = "top_1";
    dollState["bags"] = "";
    dollState["hats"] = "";
    dollState["bottoms"] = "bottom_1";
    dollState["shoes"] = "shoe_1";

    currentCategory = "hair";

    // Категории
    categories["body"] = {"Тело", {"body"}};
    categories["hair"] = {"Волосы", {"hair_1", "hair_2", "hair_3"}};
    categories["eyes"] = {"Глаза", {"eyes_1", "eyes_2", "eyes_3"}};
    categories["brows"] = {"Брови", {"brows_1", "brows_2", "brows_3"}};
    categories["mouth"] = {"Рот", {"mouth_1", "mouth_2", "mouth_3"}};
    categories["jackets"] = {"Куртки", {"jacket_1", "jacket_2"}};
    categories["tops"] = {"Топы", {"top_1", "top_2"}};
    categories["bags"] = {"Сумки", {"bag_1", "bag_2"}};
    categories["hats"] = {"Головные уборы", {"hat_1", "hat_2"}};
    categories["bottoms"] = {"Низ", {"bottom_1", "bottom_2"}};
    categories["shoes"] = {"Обувь", {"shoe_1", "shoe_2"}};

    // Конфигурации
    itemConfigs["body"]["body"] = {250, 350, 0, 0};
    itemConfigs["hair"]["hair_1"] = {300, 130, 0, -120};
    itemConfigs["hair"]["hair_2"] = {300, 220, 0, -85};
    itemConfigs["hair"]["hair_3"] = {300, 170, 0, -90};
    itemConfigs["eyes"]["eyes_1"] = {90, 80, 0, -105};
    itemConfigs["eyes"]["eyes_2"] = {90, 80, 0, -107};
    itemConfigs["eyes"]["eyes_3"] = {90, 80, 0, -110};
    itemConfigs["brows"]["brows_1"] = {90, 80, 0, -107};
    itemConfigs["brows"]["brows_2"] = {90, 80, 0, -105};
    itemConfigs["brows"]["brows_3"] = {90, 80, 0, -110};
    itemConfigs["mouth"]["mouth_1"] = {100, 60, 0, -103};
    itemConfigs["mouth"]["mouth_2"] = {100, 60, 0, -100};
    itemConfigs["mouth"]["mouth_3"] = {100, 60, 0, -106};
    itemConfigs["jackets"]["jacket_1"] = {100, 500, 0, -20};
    itemConfigs["jackets"]["jacket_2"] = {100, 500, 0, -20};
    itemConfigs["tops"]["top_1"] = {64, 200, 0, -26};
    itemConfigs["tops"]["top_2"] = {77, 200, 0, -39};
    itemConfigs["bags"]["bag_1"] = {120, 150, 15, -8};
    itemConfigs["bags"]["bag_2"] = {100, 150, -20, -10};
    itemConfigs["hats"]["hat_1"] = {82, 150, 22, -160};
    itemConfigs["hats"]["hat_2"] = {200, 150, 0, -185};
    itemConfigs["bottoms"]["bottom_1"] = {119, 200, 0, 40};
    itemConfigs["bottoms"]["bottom_2"] = {74, 200, 0, 77};
    itemConfigs["shoes"]["shoe_1"] = {87, 100, 0, 160};
    itemConfigs["shoes"]["shoe_2"] = {64, 100, 0, 159};

    // Загружаем сохраненные данные
    loadData();
    setupClothingShop();
    setupUI();
    debugPaths();
}

MainWindow::~MainWindow()
{
    saveData();
    if (shopWindow) {
        shopWindow->close();
        delete shopWindow;
        shopWindow = nullptr;
    }
}

void MainWindow::debugPaths()
{
    qDebug() << "========================================";
    qDebug() << "Application path:" << QApplication::applicationDirPath();
    qDebug() << "Current path:" << QDir::currentPath();
    qDebug() << "Money:" << money;
    qDebug() << "========================================";

    QStringList categoriesList;
    categoriesList << "body" << "hair" << "eyes" << "brows" << "mouth"
                   << "jackets" << "tops" << "bags" << "hats" << "bottoms" << "shoes";

    for (int i = 0; i < categoriesList.size(); ++i) {
        const QString &cat = categoriesList[i];

        QString path1 = QApplication::applicationDirPath() + "/" + cat;
        bool exists1 = QDir(path1).exists();
        qDebug() << "Checking:" << path1 << "->" << (exists1 ? "FOUND ✓" : "NOT FOUND ✗");

        QString path2 = QApplication::applicationDirPath() + "/../" + cat;
        bool exists2 = QDir(path2).exists();
        qDebug() << "Checking:" << path2 << "->" << (exists2 ? "FOUND ✓" : "NOT FOUND ✗");
    }
    qDebug() << "========================================";
}

void MainWindow::saveData()
{
    QSettings settings("PastelGirl", "GameData");
    settings.setValue("money", money);

    QMapIterator<QString, QMap<QString, ClothingItem>> catIt(shopItems);
    while (catIt.hasNext()) {
        catIt.next();
        const QString &category = catIt.key();
        QMapIterator<QString, ClothingItem> itemIt(catIt.value());
        while (itemIt.hasNext()) {
            itemIt.next();
            const QString &itemKey = itemIt.key();
            settings.setValue("unlock/" + category + "/" + itemKey,
                              shopItems[category][itemKey].isUnlocked);
        }
    }
}

void MainWindow::loadData()
{
    QSettings settings("PastelGirl", "GameData");
    money = settings.value("money", 0).toInt();
}

void MainWindow::setupClothingShop()
{
    shopItems["hair"]["hair_1"] = {"Волосы 1", "hair", "hair_1", 0, true};
    shopItems["hair"]["hair_2"] = {"Волосы 2", "hair", "hair_2", 10, false};
    shopItems["hair"]["hair_3"] = {"Волосы 3", "hair", "hair_3", 15, false};

    shopItems["eyes"]["eyes_1"] = {"Глаза 1", "eyes", "eyes_1", 0, true};
    shopItems["eyes"]["eyes_2"] = {"Глаза 2", "eyes", "eyes_2", 8, false};
    shopItems["eyes"]["eyes_3"] = {"Глаза 3", "eyes", "eyes_3", 12, false};

    shopItems["brows"]["brows_1"] = {"Брови 1", "brows", "brows_1", 0, true};
    shopItems["brows"]["brows_2"] = {"Брови 2", "brows", "brows_2", 5, false};
    shopItems["brows"]["brows_3"] = {"Брови 3", "brows", "brows_3", 8, false};

    shopItems["mouth"]["mouth_1"] = {"Рот 1", "mouth", "mouth_1", 0, true};
    shopItems["mouth"]["mouth_2"] = {"Рот 2", "mouth", "mouth_2", 7, false};
    shopItems["mouth"]["mouth_3"] = {"Рот 3", "mouth", "mouth_3", 10, false};

    shopItems["jackets"]["jacket_1"] = {"Куртка 1", "jackets", "jacket_1", 0, true};
    shopItems["jackets"]["jacket_2"] = {"Куртка 2", "jackets", "jacket_2", 20, false};

    shopItems["tops"]["top_1"] = {"Топ 1", "tops", "top_1", 0, true};
    shopItems["tops"]["top_2"] = {"Топ 2", "tops", "top_2", 15, false};

    shopItems["bags"]["bag_1"] = {"Сумка 1", "bags", "bag_1", 0, true};
    shopItems["bags"]["bag_2"] = {"Сумка 2", "bags", "bag_2", 25, false};

    shopItems["hats"]["hat_1"] = {"Шляпа 1", "hats", "hat_1", 0, true};
    shopItems["hats"]["hat_2"] = {"Шляпа 2", "hats", "hat_2", 18, false};

    shopItems["bottoms"]["bottom_1"] = {"Низ 1", "bottoms", "bottom_1", 0, true};
    shopItems["bottoms"]["bottom_2"] = {"Низ 2", "bottoms", "bottom_2", 12, false};

    shopItems["shoes"]["shoe_1"] = {"Обувь 1", "shoes", "shoe_1", 0, true};
    shopItems["shoes"]["shoe_2"] = {"Обувь 2", "shoes", "shoe_2", 20, false};

    QSettings settings("PastelGirl", "GameData");
    QMapIterator<QString, QMap<QString, ClothingItem>> catIt(shopItems);
    while (catIt.hasNext()) {
        catIt.next();
        const QString &category = catIt.key();
        QMapIterator<QString, ClothingItem> itemIt(catIt.value());
        while (itemIt.hasNext()) {
            itemIt.next();
            const QString &itemKey = itemIt.key();
            shopItems[category][itemKey].isUnlocked =
                settings.value("unlock/" + category + "/" + itemKey,
                               shopItems[category][itemKey].isUnlocked).toBool();
        }
    }
}

void MainWindow::updateMoneyDisplay()
{
    QString moneyText = "👠 " + QString::number(money);
    if (moneyLabelSelection) {
        moneyLabelSelection->setText(moneyText);
    }
    if (moneyLabelDoll) {
        moneyLabelDoll->setText(moneyText);
    }
}

void MainWindow::addMoney(int amount)
{
    money += amount;
    updateMoneyDisplay();
    saveData();
}

bool MainWindow::canAfford(int price)
{
    return money >= price;
}

void MainWindow::unlockItem(const QString &category, const QString &item)
{
    if (!shopItems.contains(category) || !shopItems[category].contains(item)) {
        return;
    }

    ClothingItem &clothing = shopItems[category][item];

    if (clothing.isUnlocked) {
        QMessageBox::information(this, "Уже открыто", "Этот предмет уже открыт!");
        return;
    }

    if (!canAfford(clothing.price)) {
        QMessageBox::warning(this, "Недостаточно туфелек",
                             "У вас " + QString::number(money) + " туфелек, а нужно " +
                                 QString::number(clothing.price) + " 👠");
        return;
    }

    money -= clothing.price;
    clothing.isUnlocked = true;

    updateMoneyDisplay();
    saveData();

    QMessageBox::information(this, "Покупка успешна!",
                             "🎉 Вы открыли " + clothing.name + "!\nОсталось: " +
                                 QString::number(money) + " туфелек 👠");

    if (shopWindow) {
        shopWindow->close();
        shopWindow = nullptr;
        openShop();
    }

    selectCategory(currentCategory);
    updateDoll();
}

void MainWindow::openShop()
{
    if (shopWindow) {
        shopWindow->show();
        shopWindow->raise();
        return;
    }

    shopWindow = new QWidget(this);
    shopWindow->setWindowTitle("👠 Магазин одежды");
    shopWindow->setFixedSize(450, 450);
    shopWindow->setStyleSheet("background-color: #FFF0F5;");
    shopWindow->setWindowFlags(Qt::Window);
    shopWindow->setAttribute(Qt::WA_DeleteOnClose);
    connect(shopWindow, &QWidget::destroyed, this, [this]() {
        shopWindow = nullptr;
    });

    QVBoxLayout *layout = new QVBoxLayout(shopWindow);
    layout->setSpacing(10);

    QLabel *title = new QLabel("🛍️ Магазин одежды");
    title->setAlignment(Qt::AlignCenter);
    title->setStyleSheet("font-size: 22px; font-weight: bold; color: #8B008B;");
    layout->addWidget(title);

    QLabel *moneyShop = new QLabel("👠 Ваши туфельки: " + QString::number(money));
    moneyShop->setAlignment(Qt::AlignCenter);
    moneyShop->setStyleSheet("font-size: 16px; color: #FF1493; background: rgba(255,255,255,0.5); padding: 5px; border-radius: 10px;");
    layout->addWidget(moneyShop);

    QScrollArea *scrollArea = new QScrollArea();
    scrollArea->setWidgetResizable(true);
    scrollArea->setStyleSheet("background: transparent; border: none;");
    scrollArea->setFixedHeight(300);

    QWidget *shopContent = new QWidget();
    QVBoxLayout *shopLayout = new QVBoxLayout(shopContent);
    shopLayout->setSpacing(5);
    shopLayout->setContentsMargins(5, 5, 5, 5);

    bool hasItems = false;

    QMapIterator<QString, QMap<QString, ClothingItem>> catIt(shopItems);
    while (catIt.hasNext()) {
        catIt.next();
        const QString &category = catIt.key();
        const QMap<QString, ClothingItem> &items = catIt.value();

        if (category == "body") continue;

        bool categoryHasItems = false;
        QMapIterator<QString, ClothingItem> itemIt(items);
        while (itemIt.hasNext()) {
            itemIt.next();
            if (!itemIt.value().isUnlocked) {
                categoryHasItems = true;
                hasItems = true;
                break;
            }
        }

        if (!categoryHasItems) continue;

        QLabel *catLabel = new QLabel(categories[category].label);
        catLabel->setStyleSheet("font-size: 14px; font-weight: bold; color: #8B008B; margin-top: 8px;");
        shopLayout->addWidget(catLabel);

        QMapIterator<QString, ClothingItem> itemIt2(items);
        while (itemIt2.hasNext()) {
            itemIt2.next();
            const QString &itemKey = itemIt2.key();
            const ClothingItem &item = itemIt2.value();

            if (item.isUnlocked) continue;

            QHBoxLayout *itemLayout = new QHBoxLayout();
            itemLayout->setSpacing(10);

            QLabel *nameLabel = new QLabel(item.name);
            nameLabel->setStyleSheet("font-size: 13px; color: #4A4A4A;");
            nameLabel->setFixedWidth(90);
            itemLayout->addWidget(nameLabel);

            itemLayout->addStretch();

            QLabel *priceLabel = new QLabel("👠 " + QString::number(item.price));
            priceLabel->setStyleSheet("color: #FF1493; font-weight: bold; font-size: 13px;");
            priceLabel->setFixedWidth(50);
            itemLayout->addWidget(priceLabel);

            QPushButton *buyBtn = new QPushButton("Купить");
            buyBtn->setFixedSize(70, 28);
            buyBtn->setStyleSheet(
                "QPushButton {"
                "    background-color: #FFB6C1;"
                "    border: 2px solid #FF69B4;"
                "    border-radius: 10px;"
                "    color: #8B008B;"
                "    font-weight: bold;"
                "    font-size: 12px;"
                "}"
                "QPushButton:hover {"
                "    background-color: #FF69B4;"
                "    color: white;"
                "}"
                );
            buyBtn->setProperty("category", category);
            buyBtn->setProperty("item", itemKey);
            connect(buyBtn, &QPushButton::clicked, this, [this, category, itemKey]() {
                unlockItem(category, itemKey);
            });
            itemLayout->addWidget(buyBtn);

            shopLayout->addLayout(itemLayout);
        }
    }

    if (!hasItems) {
        QLabel *emptyLabel = new QLabel("🎉 Вся одежда уже открыта!");
        emptyLabel->setAlignment(Qt::AlignCenter);
        emptyLabel->setStyleSheet("font-size: 18px; color: #8B008B; padding: 20px;");
        shopLayout->addWidget(emptyLabel);
    }

    shopLayout->addStretch();
    scrollArea->setWidget(shopContent);
    layout->addWidget(scrollArea);

    QPushButton *closeBtn = new QPushButton("Закрыть магазин");
    closeBtn->setFixedSize(180, 35);
    closeBtn->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 15px;"
        "    color: #8B008B;"
        "    font-size: 14px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "    color: white;"
        "}"
        );
    connect(closeBtn, &QPushButton::clicked, shopWindow, &QWidget::close);
    layout->addWidget(closeBtn, 0, Qt::AlignCenter);

    shopWindow->show();
}

void MainWindow::onTicTacToeWin()
{
    addMoney(5);
    QMessageBox::information(this, "🎉 Победа!",
                             "Вы выиграли в крестики-нолики!\nПолучено: +5 👠 туфелек!\nВсего: " +
                                 QString::number(money) + " 👠");
}

void MainWindow::setupUI()
{
    setWindowTitle("Pastel Girl Adventure");
    setFixedSize(900, 700);
    setStyleSheet("background-color: #FFF0F5;");

    stackedWidget = new QStackedWidget(this);
    setCentralWidget(stackedWidget);

    setupStartScreen();
    setupRandomScreen();
    setupSelectionScreen();
    setupDollGameScreen();

    tictactoeContainer = new QWidget();
    QVBoxLayout *tictactoeLayout = new QVBoxLayout(tictactoeContainer);
    tictactoeLayout->setContentsMargins(0, 0, 0, 0);

    tictactoeGame = new TicTacToe(tictactoeContainer);
    tictactoeLayout->addWidget(tictactoeGame);

    connect(tictactoeGame, &TicTacToe::playerWon, this, &MainWindow::onTicTacToeWin);

    QPushButton *backFromTicTacToe = new QPushButton("🔙 Назад к выбору игры");
    backFromTicTacToe->setFixedHeight(40);
    backFromTicTacToe->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 20px;"
        "    color: #8B008B;"
        "    font-size: 14px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "    color: white;"
        "}"
        );
    connect(backFromTicTacToe, &QPushButton::clicked, this, &MainWindow::goToSelectionScreen);
    tictactoeLayout->addWidget(backFromTicTacToe);

    stackedWidget->addWidget(tictactoeContainer);

    stackedWidget->setCurrentWidget(startScreen);
}

void MainWindow::setupStartScreen()
{
    startScreen = new QWidget();
    startScreen->setStyleSheet("background-color: #FFF0F5;");

    QVBoxLayout *mainLayout = new QVBoxLayout(startScreen);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    QLabel *bgLabel = new QLabel(startScreen);
    bgLabel->setGeometry(0, 0, 900, 700);
    bgLabel->setAlignment(Qt::AlignCenter);
    bgLabel->setStyleSheet("background: transparent;");
    bgLabel->lower();

    QString bgPath = getPath("background", "background_start");
    QPixmap bgPixmap(bgPath);
    if (!bgPixmap.isNull()) {
        bgLabel->setPixmap(bgPixmap.scaled(900, 700, Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
    } else {
        bgLabel->setStyleSheet(
            "background: qlineargradient(x1:0, y1:0, x2:0, y2:1,"
            "                            stop:0 #FFE4E1, stop:0.5 #FFF0F5, stop:1 #FFE4E1);"
            );
    }

    QWidget *centerContainer = new QWidget(startScreen);
    centerContainer->setStyleSheet("background: transparent;");
    centerContainer->setGeometry(0, 0, 900, 700);

    QVBoxLayout *centerLayout = new QVBoxLayout(centerContainer);
    centerLayout->setAlignment(Qt::AlignCenter);
    centerLayout->setSpacing(25);
    centerLayout->setContentsMargins(0, 0, 0, 20);

    QLabel *titleLabel = new QLabel("🌸 Pastel Girl Adventure 🌸");
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 52px;"
        "font-weight: bold;"
        "color: #FF1493;"
        "background: transparent;"
        "font-family: Arial;"
        "letter-spacing: 2px;"
        );
    centerLayout->addWidget(titleLabel);

    QLabel *subTitle = new QLabel("✨ Выбери место и создай свой стиль! ✨");
    subTitle->setAlignment(Qt::AlignCenter);
    subTitle->setStyleSheet(
        "font-size: 22px;"
        "color: #8B008B;"
        "background: transparent;"
        "font-style: italic;"
        "font-family: Arial;"
        );
    centerLayout->addWidget(subTitle);

    playButton = new QPushButton("▶ НАЧАТЬ");
    playButton->setFixedSize(350, 85);
    playButton->setStyleSheet(
        "QPushButton {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #FF69B4, stop:0.5 #FF1493, stop:1 #C71585);"
        "    border: none;"
        "    border-radius: 42px;"
        "    color: white;"
        "    font-size: 32px;"
        "    font-weight: bold;"
        "    font-family: Arial;"
        "    letter-spacing: 2px;"
        "}"
        "QPushButton:hover {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #FF1493, stop:0.5 #C71585, stop:1 #8B008B);"
        "}"
        "QPushButton:pressed {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #C71585, stop:1 #8B008B);"
        "}"
        );
    connect(playButton, &QPushButton::clicked, this, &MainWindow::startGame);

    QGraphicsOpacityEffect *effect = new QGraphicsOpacityEffect();
    playButton->setGraphicsEffect(effect);

    QPropertyAnimation *anim = new QPropertyAnimation(effect, "opacity");
    anim->setDuration(1200);
    anim->setStartValue(0.7);
    anim->setEndValue(1.0);
    anim->setLoopCount(-1);
    anim->start();

    centerLayout->addWidget(playButton);

    QLabel *footerLabel = new QLabel("🌸 Собери свой идеальный образ 🌸");
    footerLabel->setAlignment(Qt::AlignCenter);
    footerLabel->setStyleSheet(
        "font-size: 18px;"
        "color: #FF69B4;"
        "background: transparent;"
        "font-style: italic;"
        "font-family: Arial;"
        "letter-spacing: 1px;"
        );
    centerLayout->addWidget(footerLabel);

    centerLayout->insertStretch(0, 1);
    centerLayout->insertStretch(4, 1);

    stackedWidget->addWidget(startScreen);
}

void MainWindow::setupRandomScreen()
{
    randomScreen = new QWidget();
    randomScreen->setStyleSheet("background-color: #FFF0F5;");

    QVBoxLayout *layout = new QVBoxLayout(randomScreen);
    layout->setAlignment(Qt::AlignCenter);
    layout->setSpacing(20);

    QLabel *titleLabel = new QLabel("🎯 Куда мы идем?", randomScreen);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 36px;"
        "font-weight: bold;"
        "color: #8B008B;"
        "background: transparent;"
        );
    layout->addWidget(titleLabel);

    QWidget *placeWidget = new QWidget(randomScreen);
    placeWidget->setFixedSize(500, 300);
    placeWidget->setStyleSheet(
        "background: rgba(255, 182, 193, 0.3);"
        "border-radius: 20px;"
        "border: 3px solid #FF69B4;"
        );

    QVBoxLayout *placeLayout = new QVBoxLayout(placeWidget);
    placeLayout->setAlignment(Qt::AlignCenter);
    placeLayout->setSpacing(15);

    placeNameLabel = new QLabel("❓ Нажми РАНДОМ", placeWidget);
    placeNameLabel->setAlignment(Qt::AlignCenter);
    placeNameLabel->setStyleSheet(
        "font-size: 32px;"
        "font-weight: bold;"
        "color: #FF1493;"
        "background: transparent;"
        );
    placeLayout->addWidget(placeNameLabel);

    placeImageLabel = new QLabel(placeWidget);
    placeImageLabel->setFixedSize(400, 150);
    placeImageLabel->setAlignment(Qt::AlignCenter);
    placeImageLabel->setStyleSheet(
        "background: transparent;"
        "border-radius: 10px;"
        );
    placeLayout->addWidget(placeImageLabel);

    layout->addWidget(placeWidget);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->setAlignment(Qt::AlignCenter);
    buttonLayout->setSpacing(20);

    randomButton = new QPushButton("🎲 РАНДОМ", randomScreen);
    randomButton->setFixedSize(200, 60);
    randomButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 30px;"
        "    color: #8B008B;"
        "    font-size: 20px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "    color: white;"
        "}"
        );
    connect(randomButton, &QPushButton::clicked, this, &MainWindow::showRandomPlace);
    buttonLayout->addWidget(randomButton);

    goButton = new QPushButton("✅ ПОЕХАЛИ!", randomScreen);
    goButton->setFixedSize(200, 60);
    goButton->setEnabled(false);
    goButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #D3D3D3;"
        "    border: 2px solid #A9A9A9;"
        "    border-radius: 30px;"
        "    color: #808080;"
        "    font-size: 20px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:enabled {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #32CD32, stop:1 #228B22);"
        "    border: none;"
        "    color: white;"
        "}"
        "QPushButton:enabled:hover {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #228B22, stop:1 #006400);"
        "}"
        );
    connect(goButton, &QPushButton::clicked, this, &MainWindow::goToSelectionScreen);
    buttonLayout->addWidget(goButton);

    layout->addLayout(buttonLayout);

    animationTimer = new QTimer(this);
    animationTimer->setInterval(80);
    connect(animationTimer, &QTimer::timeout, this, [this]() {
        int idx = animationStep % animationPlaces.size();
        placeNameLabel->setText(animationPlaces[idx]);
        animationStep++;
    });

    stackedWidget->addWidget(randomScreen);
}

void MainWindow::setupSelectionScreen()
{
    selectionScreen = new QWidget();
    selectionScreen->setStyleSheet("background-color: #FFF0F5;");

    QVBoxLayout *mainLayout = new QVBoxLayout(selectionScreen);
    mainLayout->setAlignment(Qt::AlignCenter);
    mainLayout->setSpacing(20);

    QHBoxLayout *topBar = new QHBoxLayout();
    topBar->setAlignment(Qt::AlignRight);

    moneyLabelSelection = new QLabel("👠 " + QString::number(money));
    moneyLabelSelection->setStyleSheet(
        "font-size: 20px;"
        "font-weight: bold;"
        "color: #FF1493;"
        "background: rgba(255, 255, 255, 0.5);"
        "padding: 8px 20px;"
        "border-radius: 15px;"
        "border: 2px solid #FF69B4;"
        );
    topBar->addWidget(moneyLabelSelection);

    shopButtonSelection = new QPushButton("🛍️ Магазин");
    shopButtonSelection->setFixedSize(120, 40);
    shopButtonSelection->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 20px;"
        "    color: #8B008B;"
        "    font-size: 14px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "    color: white;"
        "}"
        );
    connect(shopButtonSelection, &QPushButton::clicked, this, &MainWindow::openShop);
    topBar->addWidget(shopButtonSelection);

    mainLayout->addLayout(topBar);

    QLabel *titleLabel = new QLabel("🎮 Выберите игру 🎮");
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 32px;"
        "font-weight: bold;"
        "color: #8B008B;"
        "background: transparent;"
        );
    mainLayout->addWidget(titleLabel);

    placeDisplaySelection = new QLabel("📍 Мы идем в: " + currentPlace);
    placeDisplaySelection->setAlignment(Qt::AlignCenter);
    placeDisplaySelection->setStyleSheet(
        "font-size: 20px;"
        "color: #FF1493;"
        "background: transparent;"
        "font-weight: bold;"
        );
    mainLayout->addWidget(placeDisplaySelection);

    QWidget *gamesContainer = new QWidget();
    QHBoxLayout *gamesLayout = new QHBoxLayout(gamesContainer);
    gamesLayout->setSpacing(30);
    gamesLayout->setAlignment(Qt::AlignCenter);

    QWidget *dollGameWidget = new QWidget();
    dollGameWidget->setFixedSize(300, 350);
    dollGameWidget->setStyleSheet(
        "background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                            stop:0 #FFF0F5, stop:1 #FFE4E1);"
        "border: 3px solid #FF69B4;"
        "border-radius: 20px;"
        );
    dollGameWidget->setCursor(Qt::PointingHandCursor);

    QVBoxLayout *dollGameLayout = new QVBoxLayout(dollGameWidget);
    dollGameLayout->setAlignment(Qt::AlignCenter);
    dollGameLayout->setSpacing(10);

    QLabel *dollIcon = new QLabel("👗");
    dollIcon->setAlignment(Qt::AlignCenter);
    dollIcon->setStyleSheet("font-size: 64px; background: transparent;");
    dollGameLayout->addWidget(dollIcon);

    QLabel *dollTitle = new QLabel("Основная игра");
    dollTitle->setAlignment(Qt::AlignCenter);
    dollTitle->setStyleSheet(
        "font-size: 20px;"
        "font-weight: bold;"
        "color: #8B008B;"
        "background: transparent;"
        );
    dollGameLayout->addWidget(dollTitle);

    QLabel *dollDesc = new QLabel("Переодевание куклы");
    dollDesc->setAlignment(Qt::AlignCenter);
    dollDesc->setStyleSheet(
        "font-size: 14px;"
        "color: #FF69B4;"
        "background: transparent;"
        );
    dollGameLayout->addWidget(dollDesc);

    QLabel *dollEmoji = new QLabel("🌸");
    dollEmoji->setAlignment(Qt::AlignCenter);
    dollEmoji->setStyleSheet("font-size: 32px; background: transparent;");
    dollGameLayout->addWidget(dollEmoji);

    dollGameButton = new QPushButton("▶ Играть", dollGameWidget);
    dollGameButton->setFixedSize(150, 40);
    dollGameButton->setStyleSheet(
        "QPushButton {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #FF69B4, stop:1 #FF1493);"
        "    border: none;"
        "    border-radius: 20px;"
        "    color: white;"
        "    font-size: 16px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #FF1493, stop:1 #C71585);"
        "}"
        );
    dollGameLayout->addWidget(dollGameButton);

    gamesLayout->addWidget(dollGameWidget);

    QWidget *tictactoeWidget = new QWidget();
    tictactoeWidget->setFixedSize(300, 350);
    tictactoeWidget->setStyleSheet(
        "background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                            stop:0 #FFF0F5, stop:1 #E6E6FA);"
        "border: 3px solid #9370DB;"
        "border-radius: 20px;"
        );
    tictactoeWidget->setCursor(Qt::PointingHandCursor);

    QVBoxLayout *tictactoeGameLayout = new QVBoxLayout(tictactoeWidget);
    tictactoeGameLayout->setAlignment(Qt::AlignCenter);
    tictactoeGameLayout->setSpacing(10);

    QLabel *tttIcon = new QLabel("❌");
    tttIcon->setAlignment(Qt::AlignCenter);
    tttIcon->setStyleSheet("font-size: 64px; background: transparent;");
    tictactoeGameLayout->addWidget(tttIcon);

    QLabel *tttTitle = new QLabel("Доп игра");
    tttTitle->setAlignment(Qt::AlignCenter);
    tttTitle->setStyleSheet(
        "font-size: 20px;"
        "font-weight: bold;"
        "color: #6A5ACD;"
        "background: transparent;"
        );
    tictactoeGameLayout->addWidget(tttTitle);

    QLabel *tttDesc = new QLabel("Крестики-нолики");
    tttDesc->setAlignment(Qt::AlignCenter);
    tttDesc->setStyleSheet(
        "font-size: 14px;"
        "color: #9370DB;"
        "background: transparent;"
        );
    tictactoeGameLayout->addWidget(tttDesc);

    QLabel *tttEmoji = new QLabel("⭕");
    tttEmoji->setAlignment(Qt::AlignCenter);
    tttEmoji->setStyleSheet("font-size: 32px; background: transparent;");
    tictactoeGameLayout->addWidget(tttEmoji);

    tictactoeButton = new QPushButton("▶ Играть", tictactoeWidget);
    tictactoeButton->setFixedSize(150, 40);
    tictactoeButton->setStyleSheet(
        "QPushButton {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #9370DB, stop:1 #6A5ACD);"
        "    border: none;"
        "    border-radius: 20px;"
        "    color: white;"
        "    font-size: 16px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                                stop:0 #6A5ACD, stop:1 #483D8B);"
        "}"
        );
    tictactoeGameLayout->addWidget(tictactoeButton);

    gamesLayout->addWidget(tictactoeWidget);

    mainLayout->addWidget(gamesContainer);

    QPushButton *backButton = new QPushButton("🔙 Назад к выбору места");
    backButton->setFixedSize(200, 40);
    backButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 20px;"
        "    color: #8B008B;"
        "    font-size: 14px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "    color: white;"
        "}"
        );
    connect(backButton, &QPushButton::clicked, this, [this]() {
        stackedWidget->setCurrentWidget(randomScreen);
    });
    mainLayout->addWidget(backButton);

    connect(dollGameButton, &QPushButton::clicked, this, &MainWindow::goToDollGame);
    connect(tictactoeButton, &QPushButton::clicked, this, &MainWindow::goToTicTacToe);

    stackedWidget->addWidget(selectionScreen);
}

void MainWindow::setupDollGameScreen()
{
    dollGameScreen = new QWidget();
    dollGameScreen->setStyleSheet("background-color: #FFF0F5;");

    QVBoxLayout *mainLayout = new QVBoxLayout(dollGameScreen);
    mainLayout->setContentsMargins(10, 10, 10, 10);
    mainLayout->setSpacing(10);

    QWidget *topPanel = new QWidget();
    topPanel->setFixedHeight(70);
    topPanel->setStyleSheet("background: transparent;");
    QHBoxLayout *topLayout = new QHBoxLayout(topPanel);

    QLabel *locationLabel = new QLabel("📍 Мы идем в:", topPanel);
    locationLabel->setStyleSheet(
        "font-size: 18px;"
        "font-weight: bold;"
        "color: #8B008B;"
        "background: transparent;"
        );
    topLayout->addWidget(locationLabel);

    QLabel *placeDisplayLabel = new QLabel(currentPlace, topPanel);
    placeDisplayLabel->setObjectName("placeDisplay");
    placeDisplayLabel->setStyleSheet(
        "font-size: 24px;"
        "font-weight: bold;"
        "color: #FF1493;"
        "background: transparent;"
        );
    topLayout->addWidget(placeDisplayLabel);
    topLayout->addStretch();

    moneyLabelDoll = new QLabel("👠 " + QString::number(money));
    moneyLabelDoll->setStyleSheet(
        "font-size: 18px;"
        "font-weight: bold;"
        "color: #FF1493;"
        "background: rgba(255, 255, 255, 0.5);"
        "padding: 5px 15px;"
        "border-radius: 12px;"
        "border: 2px solid #FF69B4;"
        );
    topLayout->addWidget(moneyLabelDoll);

    shopButtonDoll = new QPushButton("🛍️");
    shopButtonDoll->setFixedSize(40, 40);
    shopButtonDoll->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 20px;"
        "    font-size: 18px;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "}"
        );
    connect(shopButtonDoll, &QPushButton::clicked, this, &MainWindow::openShop);
    topLayout->addWidget(shopButtonDoll);

    QPushButton *backButton = new QPushButton("🔙 Назад", topPanel);
    backButton->setFixedSize(100, 35);
    backButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFB6C1;"
        "    border: 2px solid #FF69B4;"
        "    border-radius: 17px;"
        "    color: #8B008B;"
        "    font-size: 14px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FF69B4;"
        "    color: white;"
        "}"
        );
    connect(backButton, &QPushButton::clicked, this, &MainWindow::goToSelectionScreen);
    topLayout->addWidget(backButton);

    mainLayout->addWidget(topPanel);

    QHBoxLayout *gameLayout = new QHBoxLayout();
    gameLayout->setSpacing(10);

    QWidget *categoryPanel = new QWidget();
    categoryPanel->setFixedWidth(80);
    categoryLayout = new QVBoxLayout(categoryPanel);
    categoryLayout->setSpacing(5);
    categoryLayout->setAlignment(Qt::AlignCenter);

    QMapIterator<QString, CategoryData> it(categories);
    while (it.hasNext()) {
        it.next();
        const QString &key = it.key();
        const CategoryData &data = it.value();

        QPushButton *btn = new QPushButton(data.label);
        btn->setFixedSize(70, 30);
        btn->setCheckable(true);
        btn->setStyleSheet(
            "QPushButton {"
            "    background-color: #FFE4E1;"
            "    border: 2px solid #FFB6C1;"
            "    border-radius: 5px;"
            "    color: #8B008B;"
            "    font-size: 10px;"
            "}"
            "QPushButton:checked {"
            "    background-color: #FFB6C1;"
            "    border: 2px solid #FF69B4;"
            "}"
            "QPushButton:hover {"
            "    background-color: #FFD0D0;"
            "}"
            );

        connect(btn, &QPushButton::clicked, this, [this, key]() {
            selectCategory(key);
        });

        categoryLayout->addWidget(btn);
        categoryButtons[key] = btn;
    }

    categoryLayout->addStretch();
    gameLayout->addWidget(categoryPanel);

    setupDoll();
    gameLayout->addWidget(dollContainer, 1);

    QWidget *bottomPanel = new QWidget();
    bottomPanel->setFixedHeight(120);
    bottomPanel->setStyleSheet("background: transparent;");
    QHBoxLayout *bottomLayout = new QHBoxLayout(bottomPanel);
    bottomLayout->setContentsMargins(10, 10, 10, 10);
    bottomLayout->setSpacing(10);

    QPushButton *removeBtn = new QPushButton("✕ Снять");
    removeBtn->setFixedSize(70, 40);
    removeBtn->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFE4E1;"
        "    border: 2px solid #FFB6C1;"
        "    border-radius: 5px;"
        "    color: #8B008B;"
        "    font-size: 10px;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FFD0D0;"
        "}"
        );
    connect(removeBtn, &QPushButton::clicked, this, &MainWindow::removeItem);
    bottomLayout->addWidget(removeBtn);

    itemsScrollArea = new QScrollArea();
    itemsScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    itemsScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    itemsScrollArea->setStyleSheet(
        "QScrollArea {"
        "    background: transparent;"
        "    border: none;"
        "}"
        "QScrollBar:horizontal {"
        "    height: 10px;"
        "    background: #FFE4E1;"
        "    border-radius: 5px;"
        "}"
        "QScrollBar::handle:horizontal {"
        "    background: #FFB6C1;"
        "    border-radius: 5px;"
        "    min-width: 20px;"
        "}"
        "QScrollBar::handle:horizontal:hover {"
        "    background: #FF69B4;"
        "}"
        "QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {"
        "    border: none;"
        "    background: none;"
        "}"
        );
    itemsScrollArea->setFixedHeight(100);

    itemsPanel = new QWidget();
    itemsLayout = new QHBoxLayout(itemsPanel);
    itemsLayout->setContentsMargins(5, 5, 5, 5);
    itemsLayout->setSpacing(10);
    itemsLayout->setAlignment(Qt::AlignLeft);
    itemsPanel->setStyleSheet("background: transparent;");

    itemsScrollArea->setWidget(itemsPanel);
    itemsScrollArea->setWidgetResizable(true);
    bottomLayout->addWidget(itemsScrollArea);

    QVBoxLayout *rightLayout = new QVBoxLayout();
    rightLayout->addLayout(gameLayout);
    rightLayout->addWidget(bottomPanel);
    mainLayout->addLayout(rightLayout, 1);

    stackedWidget->addWidget(dollGameScreen);

    selectCategory(currentCategory);
    updateDoll();
}

void MainWindow::setupDoll()
{
    dollContainer = new QWidget();
    dollContainer->setFixedSize(600, 500);
    dollContainer->setStyleSheet("background: transparent;");

    QWidget *dollWidget = new QWidget(dollContainer);
    dollWidget->setFixedSize(600, 500);
    dollWidget->setStyleSheet("background: transparent;");

    bodyLabel = new QLabel(dollWidget);
    hairLabel = new QLabel(dollWidget);
    eyesLabel = new QLabel(dollWidget);
    browsLabel = new QLabel(dollWidget);
    mouthLabel = new QLabel(dollWidget);
    topLabel = new QLabel(dollWidget);
    jacketLabel = new QLabel(dollWidget);
    bottomLabel = new QLabel(dollWidget);
    shoesLabel = new QLabel(dollWidget);
    bagLabel = new QLabel(dollWidget);
    hatLabel = new QLabel(dollWidget);

    QList<QLabel*> labels;
    labels << bodyLabel << hairLabel << eyesLabel << browsLabel << mouthLabel
           << topLabel << jacketLabel << bottomLabel << shoesLabel << bagLabel << hatLabel;

    for (int i = 0; i < labels.size(); ++i) {
        QLabel *label = labels[i];
        label->setScaledContents(false);
        label->setAlignment(Qt::AlignCenter);
        label->setStyleSheet("background: transparent;");
    }
}

void MainWindow::startGame()
{
    stackedWidget->setCurrentWidget(randomScreen);
}

void MainWindow::showRandomPlace()
{
    animationStep = 0;
    randomButton->setEnabled(false);
    goButton->setEnabled(false);
    animationTimer->start();

    QTimer::singleShot(2000, this, [this]() {
        animationTimer->stop();
        randomButton->setEnabled(true);

        int randomIndex = QRandomGenerator::global()->bounded(places.size());
        currentPlace = places[randomIndex];
        placeNameLabel->setText(currentPlace);

        QString cleanPlace = currentPlace.split(" ").first().toLower();
        QString placeImagePath = getPath("places", "place_" + cleanPlace);
        QPixmap placePixmap(placeImagePath);
        if (!placePixmap.isNull()) {
            placeImageLabel->setPixmap(placePixmap.scaled(400, 150, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        } else {
            placeImageLabel->setText("🖼️ " + cleanPlace.toUpper());
            placeImageLabel->setStyleSheet(
                "font-size: 24px;"
                "color: #8B008B;"
                "background: #FFE4E1;"
                "border-radius: 10px;"
                );
        }

        goButton->setEnabled(true);
        goButton->setStyleSheet(
            "QPushButton {"
            "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
            "                                stop:0 #32CD32, stop:1 #228B22);"
            "    border: none;"
            "    border-radius: 30px;"
            "    color: white;"
            "    font-size: 20px;"
            "    font-weight: bold;"
            "}"
            "QPushButton:hover {"
            "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
            "                                stop:0 #228B22, stop:1 #006400);"
            "}"
            );
    });
}

void MainWindow::goToSelectionScreen()
{
    if (placeDisplaySelection) {
        placeDisplaySelection->setText("📍 Мы идем в: " + currentPlace);
    }
    updateMoneyDisplay();
    stackedWidget->setCurrentWidget(selectionScreen);
}

void MainWindow::goToDollGame()
{
    QLabel *placeDisplay = dollGameScreen->findChild<QLabel*>("placeDisplay");
    if (placeDisplay) {
        placeDisplay->setText(currentPlace);
    }
    updateMoneyDisplay();
    stackedWidget->setCurrentWidget(dollGameScreen);
}

void MainWindow::goToTicTacToe()
{
    stackedWidget->setCurrentWidget(tictactoeContainer);
}

void MainWindow::selectCategory(const QString &category)
{
    currentCategory = category;

    QMapIterator<QString, QPushButton*> it(categoryButtons);
    while (it.hasNext()) {
        it.next();
        it.value()->setChecked(it.key() == category);
    }

    clearLayout(itemsLayout);

    const CategoryData &catData = categories[category];
    const QStringList &items = catData.items;

    for (int i = 0; i < items.size(); ++i) {
        const QString &item = items[i];

        bool isUnlocked = true;
        if (shopItems.contains(category) && shopItems[category].contains(item)) {
            isUnlocked = shopItems[category][item].isUnlocked;
        }

        QPushButton *btn = new QPushButton(itemsPanel);
        btn->setFixedSize(70, 90);
        btn->setStyleSheet(
            "QPushButton {"
            "    background-color: white;"
            "    border: 2px solid #FFB6C1;"
            "    border-radius: 5px;"
            "}"
            "QPushButton:hover {"
            "    border-color: #FF69B4;"
            "    background-color: #FFF0F5;"
            "}"
            );

        QVBoxLayout *btnLayout = new QVBoxLayout(btn);
        btnLayout->setSpacing(2);
        btnLayout->setContentsMargins(5, 5, 5, 5);
        btnLayout->setAlignment(Qt::AlignCenter);

        QLabel *iconLabel = new QLabel(btn);
        iconLabel->setFixedSize(50, 50);
        iconLabel->setScaledContents(false);
        iconLabel->setStyleSheet("background: transparent;");
        iconLabel->setAlignment(Qt::AlignCenter);

        if (!isUnlocked) {
            iconLabel->setText("🔒");
            iconLabel->setStyleSheet("font-size: 32px;");
            btn->setEnabled(false);
        } else {
            QString path = getPath(category, item);
            if (QFile::exists(path)) {
                QPixmap pixmap(path);
                if (!pixmap.isNull()) {
                    QPixmap scaled = pixmap.scaled(50, 50, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                    iconLabel->setPixmap(scaled);
                }
            } else {
                iconLabel->setText("🖼️");
                iconLabel->setStyleSheet("font-size: 24px;");
            }
        }
        btnLayout->addWidget(iconLabel);

        QString displayName = item;
        if (item == "body") displayName = "Тело";
        else if (item == "hair_1") displayName = "Волосы 1";
        else if (item == "hair_2") displayName = "Волосы 2";
        else if (item == "hair_3") displayName = "Волосы 3";
        else if (item == "eyes_1") displayName = "Глаза 1";
        else if (item == "eyes_2") displayName = "Глаза 2";
        else if (item == "eyes_3") displayName = "Глаза 3";
        else if (item == "brows_1") displayName = "Брови 1";
        else if (item == "brows_2") displayName = "Брови 2";
        else if (item == "brows_3") displayName = "Брови 3";
        else if (item == "mouth_1") displayName = "Рот 1";
        else if (item == "mouth_2") displayName = "Рот 2";
        else if (item == "mouth_3") displayName = "Рот 3";
        else if (item == "jacket_1") displayName = "Куртка 1";
        else if (item == "jacket_2") displayName = "Куртка 2";
        else if (item == "top_1") displayName = "Топ 1";
        else if (item == "top_2") displayName = "Топ 2";
        else if (item == "bag_1") displayName = "Сумка 1";
        else if (item == "bag_2") displayName = "Сумка 2";
        else if (item == "hat_1") displayName = "Шляпа 1";
        else if (item == "hat_2") displayName = "Шляпа 2";
        else if (item == "bottom_1") displayName = "Низ 1";
        else if (item == "bottom_2") displayName = "Низ 2";
        else if (item == "shoe_1") displayName = "Обувь 1";
        else if (item == "shoe_2") displayName = "Обувь 2";

        QLabel *nameLabel = new QLabel(displayName, btn);
        nameLabel->setAlignment(Qt::AlignCenter);
        nameLabel->setStyleSheet("font-size: 8px; color: #8B008B; background: transparent;");
        btnLayout->addWidget(nameLabel);

        if (isUnlocked) {
            connect(btn, &QPushButton::clicked, this, [this, category, item]() {
                selectItem(category, item);
            });
        }

        itemsLayout->addWidget(btn);
    }

    itemsLayout->addStretch();
}

void MainWindow::clearLayout(QLayout *layout)
{
    QLayoutItem *child;
    while ((child = layout->takeAt(0)) != nullptr) {
        if (child->widget()) {
            delete child->widget();
        }
        delete child;
    }
}

void MainWindow::selectItem(const QString &category, const QString &item)
{
    dollState[category] = item;
    updateDoll();
}

void MainWindow::removeItem()
{
    dollState[currentCategory] = "";
    updateDoll();
}

void MainWindow::updateDoll()
{
    QList<QLabel*> labels;
    labels << bodyLabel << hairLabel << eyesLabel << browsLabel << mouthLabel
           << topLabel << jacketLabel << bottomLabel << shoesLabel << bagLabel << hatLabel;

    QStringList keys;
    keys << "body" << "hair" << "eyes" << "brows" << "mouth" << "tops"
         << "jackets" << "bottoms" << "shoes" << "bags" << "hats";

    for (int i = 0; i < labels.size(); ++i) {
        QLabel *label = labels[i];
        const QString &key = keys[i];
        const QString &item = dollState[key];

        if (item.isEmpty()) {
            label->clear();
            label->setVisible(false);
            continue;
        }

        label->setVisible(true);
        ItemConfig config = getConfig(key, item);
        QString path = getPath(key, item);

        if (QFile::exists(path)) {
            QPixmap pixmap(path);
            if (!pixmap.isNull()) {
                QPixmap scaled = pixmap.scaled(config.width, config.height,
                                               Qt::KeepAspectRatio,
                                               Qt::SmoothTransformation);

                if (scaled.width() < config.width || scaled.height() < config.height) {
                    QPixmap centered(config.width, config.height);
                    centered.fill(Qt::transparent);
                    QPainter painter(&centered);
                    painter.drawPixmap((config.width - scaled.width()) / 2,
                                       (config.height - scaled.height()) / 2,
                                       scaled);
                    painter.end();
                    label->setPixmap(centered);
                } else {
                    label->setPixmap(scaled);
                }

                label->setFixedSize(config.width, config.height);

                int parentWidth = dollContainer->width();
                int parentHeight = dollContainer->height();

                int x = (parentWidth - config.width) / 2 + config.offsetX;
                int y = (parentHeight - config.height) / 2 + config.offsetY;

                label->move(x, y);
            }
        }
    }
}

QString MainWindow::getPath(const QString &category, const QString &item) const
{
    if (item.isEmpty()) return QString();

    QStringList paths;

    paths << QApplication::applicationDirPath() + "/" + category + "/" + item + ".png";
    paths << QApplication::applicationDirPath() + "/../" + category + "/" + item + ".png";
    paths << QApplication::applicationDirPath() + "/../Resources/" + category + "/" + item + ".png";

    QString home = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);
    paths << home + "/QtProjects/PastelGirl/" + category + "/" + item + ".png";
    paths << home + "/Documents/PastelGirl/" + category + "/" + item + ".png";

    paths << QDir::currentPath() + "/" + category + "/" + item + ".png";
    paths << QDir::currentPath() + "/../" + category + "/" + item + ".png";

    for (int i = 0; i < paths.size(); ++i) {
        const QString &path = paths[i];
        if (QFile::exists(path)) {
            qDebug() << "✅ Found:" << path;
            return path;
        }
    }

    qDebug() << "❌ NOT FOUND for:" << category << "/" << item;
    return paths.first();
}

ItemConfig MainWindow::getConfig(const QString &category, const QString &item) const
{
    if (item.isEmpty() || !itemConfigs.contains(category)) {
        return {0, 0, 0, 0};
    }

    const QMap<QString, ItemConfig> &categoryMap = itemConfigs[category];
    if (!categoryMap.contains(item)) {
        return {0, 0, 0, 0};
    }

    return categoryMap[item];
}
