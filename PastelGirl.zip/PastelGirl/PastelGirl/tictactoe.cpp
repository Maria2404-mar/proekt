#include "tictactoe.h"
#include <QMessageBox>
#include <QVBoxLayout>
#include <QPair>
#include <climits>
#include <QTimer>
#include <QDialog>
#include <QLabel>
#include <QPushButton>

TicTacToe::TicTacToe(QWidget *parent)
    : QWidget(parent), currentPlayer('X'), gameOver(false),
    isAITurn(false), isPlayerTurn(false), moveCount(0), robotStarts(true)
{
    // ===== РОЗОВАЯ ТЕМА =====
    this->setStyleSheet(
        "QWidget {"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                               stop:0 #fff0f5, stop:1 #ffe4e1);"
        "}"
        );

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(15);

    QLabel* titleLabel = new QLabel("✨ Крестики-нолики ✨", this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 22px; font-weight: bold;"
        "color: #d4739d;"
        "font-family: 'Comic Sans MS', cursive;"
        "padding: 10px;"
        "background: rgba(255, 255, 255, 0.3);"
        "border-radius: 15px;"
        "border: 2px solid #f8b4c8;"
        );
    mainLayout->addWidget(titleLabel);

    statusLabel = new QLabel("", this);
    statusLabel->setAlignment(Qt::AlignCenter);
    statusLabel->setStyleSheet(
        "font-size: 16px; font-weight: bold;"
        "color: #b85a7a;"
        "font-family: 'Comic Sans MS', cursive;"
        "background: rgba(255, 255, 255, 0.5);"
        "padding: 8px;"
        "border-radius: 12px;"
        "border: 1px solid #f8b4c8;"
        );
    mainLayout->addWidget(statusLabel);

    QGridLayout* gridLayout = new QGridLayout();
    gridLayout->setSpacing(10);

    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            buttons[row][col] = new QPushButton("", this);
            buttons[row][col]->setFixedSize(110, 110);
            buttons[row][col]->setStyleSheet(
                "QPushButton {"
                "   font-size: 48px; font-weight: bold;"
                "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
                "                               stop:0 #fff5f7, stop:1 #ffe8ee);"
                "   border: 3px solid #f0b8cc;"
                "   border-radius: 20px;"
                "   color: #d4739d;"
                "   font-family: 'Comic Sans MS', cursive;"
                "}"
                "QPushButton:hover {"
                "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
                "                               stop:0 #ffe8ee, stop:1 #ffd5e0);"
                "   border: 3px solid #e8a0b8;"
                "}"
                "QPushButton:pressed {"
                "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
                "                               stop:0 #ffd5e0, stop:1 #ffc0d0);"
                "}"
                );
            connect(buttons[row][col], &QPushButton::clicked, this, &TicTacToe::handleButtonClick);
            gridLayout->addWidget(buttons[row][col], row, col);
        }
    }

    mainLayout->addLayout(gridLayout);

    resetButton = new QPushButton("💖 Новая игра 💖", this);
    resetButton->setFixedHeight(45);
    resetButton->setStyleSheet(
        "QPushButton {"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
        "                               stop:0 #f8b4c8, stop:1 #e890b0);"
        "   color: white;"
        "   font-size: 16px; font-weight: bold;"
        "   font-family: 'Comic Sans MS', cursive;"
        "   border-radius: 15px;"
        "   border: 2px solid #d4739d;"
        "   padding: 10px;"
        "}"
        "QPushButton:hover {"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
        "                               stop:0 #fcc0d0, stop:1 #f0a0b8);"
        "   border: 2px solid #c86888;"
        "}"
        "QPushButton:pressed {"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
        "                               stop:0 #e890b0, stop:1 #d880a0);"
        "}"
        );
    connect(resetButton, &QPushButton::clicked, this, &TicTacToe::resetGame);
    mainLayout->addWidget(resetButton);

    mainLayout->addSpacing(5);

    setWindowTitle("💗 Крестики-нолики 💗");
    setFixedSize(400, 550);
    setWindowOpacity(0.98);

    startNewGame();
}

// ===== КАСТОМНОЕ ОКНО С ЧЕРНЫМ ТЕКСТОМ =====
void TicTacToe::showCustomMessage(const QString &title, const QString &text)
{
    QDialog dialog(this);
    dialog.setWindowTitle(title);
    dialog.setFixedSize(320, 200);
    dialog.setStyleSheet(
        "QDialog {"
        "   background-color: white;"
        "   border: 2px solid #d4739d;"
        "   border-radius: 15px;"
        "}"
        );

    QVBoxLayout *layout = new QVBoxLayout(&dialog);
    layout->setSpacing(15);
    layout->setContentsMargins(20, 20, 20, 20);

    QLabel *label = new QLabel(text, &dialog);
    label->setAlignment(Qt::AlignCenter);
    label->setWordWrap(true);
    label->setStyleSheet(
        "QLabel {"
        "   color: black;"
        "   font-size: 16px;"
        "   font-weight: bold;"
        "   background: transparent;"
        "}"
        );
    layout->addWidget(label);

    QPushButton *okButton = new QPushButton("OK", &dialog);
    okButton->setFixedSize(100, 40);
    okButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #f8b4c8;"
        "   color: black;"
        "   font-size: 14px;"
        "   font-weight: bold;"
        "   border: 1px solid #d4739d;"
        "   border-radius: 10px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #e890b0;"
        "}"
        );
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);
    layout->addWidget(okButton, 0, Qt::AlignCenter);

    dialog.exec();
}

void TicTacToe::startNewGame()
{
    robotStarts = !robotStarts;

    gameOver = false;
    moveCount = 0;
    clearBoard();
    enableAllButtons();

    if (robotStarts) {
        currentPlayer = 'O';
        isAITurn = true;
        isPlayerTurn = false;
        setStatus("💭 Ход соперницы...");
        disableAllButtons();
        aiMove();
    } else {
        currentPlayer = 'X';
        isAITurn = false;
        isPlayerTurn = true;
        setStatus("🌸 Ваш ход");
        enableAllButtons();
    }
}

void TicTacToe::handleButtonClick()
{
    if (gameOver || isAITurn || !isPlayerTurn || currentPlayer != 'X') return;

    QPushButton* clickedButton = qobject_cast<QPushButton*>(sender());
    if (!clickedButton || clickedButton->text() != "") return;

    clickedButton->setText("❌");
    clickedButton->setStyleSheet(
        "QPushButton {"
        "   font-size: 52px;"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                               stop:0 #ffb6c1, stop:1 #ff8da1);"
        "   border: 3px solid #e8708a;"
        "   border-radius: 20px;"
        "   color: white;"
        "}"
        );
    moveCount++;

    checkWinner();

    if (!gameOver && !isBoardFull()) {
        currentPlayer = 'O';
        isAITurn = true;
        isPlayerTurn = false;
        setStatus("💭 Соперница думает...");
        disableAllButtons();
        aiMove();
    }
}

void TicTacToe::aiMove()
{
    if (gameOver || !isAITurn) return;

    QPair<int, int> bestMove = findBestMove();

    if (bestMove.first == -1 || bestMove.second == -1) {
        if (isBoardFull()) {
            gameOver = true;
            setStatus("🤝 Ничья!");
            // Ничья - показываем сообщение
            showCustomMessage("Игра окончена", "🤝 Ничья!");
        }
        return;
    }

    makeAIMove(bestMove.first, bestMove.second);
    moveCount++;

    checkWinner();

    if (!gameOver && !isBoardFull()) {
        currentPlayer = 'X';
        isAITurn = false;
        isPlayerTurn = true;
        setStatus("🌸 Ваш ход");
        enableAllButtons();
    } else if (!gameOver && isBoardFull()) {
        setStatus("🤝 Ничья!");
    }
}

void TicTacToe::makeAIMove(int row, int col)
{
    buttons[row][col]->setText("⭕");
    buttons[row][col]->setStyleSheet(
        "QPushButton {"
        "   font-size: 52px;"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "                               stop:0 #dda0dd, stop:1 #c98ec9);"
        "   border: 3px solid #b870b8;"
        "   border-radius: 20px;"
        "   color: white;"
        "}"
        );
}

QPair<int, int> TicTacToe::findBestMove()
{
    int bestScore = INT_MIN;
    QPair<int, int> bestMove = {-1, -1};

    int maxDepth;
    int emptyCount = 0;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (buttons[i][j]->text() == "") {
                emptyCount++;
            }
        }
    }

    if (emptyCount >= 7) {
        maxDepth = 4;
    } else if (emptyCount >= 5) {
        maxDepth = 5;
    } else if (emptyCount >= 3) {
        maxDepth = 6;
    } else {
        maxDepth = 7;
    }

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (buttons[i][j]->text() == "") {
                buttons[i][j]->setText("O");
                int score = minimax(false, 0, INT_MIN, INT_MAX, maxDepth);
                buttons[i][j]->setText("");

                if (score > bestScore) {
                    bestScore = score;
                    bestMove = {i, j};
                }
            }
        }
    }
    return bestMove;
}

int TicTacToe::minimax(bool isMaximizing, int depth, int alpha, int beta, int maxDepth)
{
    if (depth >= maxDepth) {
        return evaluateBoard();
    }

    int result = evaluateBoard();
    if (result != 0) return result - depth;
    if (isBoardFull()) return 0;

    if (isMaximizing) {
        int bestScore = INT_MIN;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (buttons[i][j]->text() == "") {
                    buttons[i][j]->setText("O");
                    int score = minimax(false, depth + 1, alpha, beta, maxDepth);
                    buttons[i][j]->setText("");
                    bestScore = std::max(bestScore, score);
                    alpha = std::max(alpha, bestScore);
                    if (beta <= alpha) {
                        i = 3;
                        break;
                    }
                }
            }
        }
        return bestScore;
    } else {
        int bestScore = INT_MAX;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (buttons[i][j]->text() == "") {
                    buttons[i][j]->setText("X");
                    int score = minimax(true, depth + 1, alpha, beta, maxDepth);
                    buttons[i][j]->setText("");
                    bestScore = std::min(bestScore, score);
                    beta = std::min(beta, bestScore);
                    if (beta <= alpha) {
                        i = 3;
                        break;
                    }
                }
            }
        }
        return bestScore;
    }
}

int TicTacToe::evaluateBoard()
{
    // Проверка строк
    for (int i = 0; i < 3; ++i) {
        if (buttons[i][0]->text() != "" &&
            buttons[i][0]->text() == buttons[i][1]->text() &&
            buttons[i][1]->text() == buttons[i][2]->text()) {
            if (buttons[i][0]->text() == "O" || buttons[i][0]->text() == "⭕") {
                return 10;
            } else {
                return -10;
            }
        }
    }

    // Проверка столбцов
    for (int i = 0; i < 3; ++i) {
        if (buttons[0][i]->text() != "" &&
            buttons[0][i]->text() == buttons[1][i]->text() &&
            buttons[1][i]->text() == buttons[2][i]->text()) {
            if (buttons[0][i]->text() == "O" || buttons[0][i]->text() == "⭕") {
                return 10;
            } else {
                return -10;
            }
        }
    }

    // Проверка диагоналей
    if (buttons[0][0]->text() != "" &&
        buttons[0][0]->text() == buttons[1][1]->text() &&
        buttons[1][1]->text() == buttons[2][2]->text()) {
        if (buttons[0][0]->text() == "O" || buttons[0][0]->text() == "⭕") {
            return 10;
        } else {
            return -10;
        }
    }

    if (buttons[0][2]->text() != "" &&
        buttons[0][2]->text() == buttons[1][1]->text() &&
        buttons[1][1]->text() == buttons[2][0]->text()) {
        if (buttons[0][2]->text() == "O" || buttons[0][2]->text() == "⭕") {
            return 10;
        } else {
            return -10;
        }
    }

    return 0;
}

bool TicTacToe::isBoardFull()
{
    return moveCount == 9;
}

void TicTacToe::checkWinner()
{
    int result = evaluateBoard();

    if (result == 10) {
        gameOver = true;
        isAITurn = false;
        isPlayerTurn = false;
        setStatus("💅 Соперница победила!");
        disableAllButtons();
        // НЕ ПОКАЗЫВАЕМ СООБЩЕНИЕ ПРИ ПОРАЖЕНИИ

    } else if (result == -10) {
        gameOver = true;
        isAITurn = false;
        isPlayerTurn = false;
        setStatus("🎉 Вы победили!");
        disableAllButtons();
        emit playerWon();  // Отправляем сигнал о победе

        // === ТОЛЬКО ЭТО СООБЩЕНИЕ ПОКАЗЫВАЕМ ===
        showCustomMessage("🎉 Победа!", "🎉 Вы победили!\n\nВы получили +5 👠 туфелек!");

    } else if (isBoardFull()) {
        gameOver = true;
        isAITurn = false;
        isPlayerTurn = false;
        setStatus("🤝 Ничья!");
        // НЕ ПОКАЗЫВАЕМ СООБЩЕНИЕ ПРИ НИЧЬЕ
    }
}

void TicTacToe::resetGame()
{
    startNewGame();
}

void TicTacToe::setStatus(const QString& text)
{
    statusLabel->setText(text);
}

void TicTacToe::disableAllButtons()
{
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            buttons[i][j]->setEnabled(false);
}

void TicTacToe::enableAllButtons()
{
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            buttons[i][j]->setEnabled(true);
}

void TicTacToe::clearBoard()
{
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            buttons[i][j]->setText("");
            buttons[i][j]->setStyleSheet(
                "QPushButton {"
                "   font-size: 48px; font-weight: bold;"
                "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
                "                               stop:0 #fff5f7, stop:1 #ffe8ee);"
                "   border: 3px solid #f0b8cc;"
                "   border-radius: 20px;"
                "   color: #d4739d;"
                "   font-family: 'Comic Sans MS', cursive;"
                "}"
                "QPushButton:hover {"
                "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
                "                               stop:0 #ffe8ee, stop:1 #ffd5e0);"
                "   border: 3px solid #e8a0b8;"
                "}"
                );
        }
    }
}
